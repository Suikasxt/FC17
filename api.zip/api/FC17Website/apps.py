from django.apps import AppConfig

class Fc17WebsiteConfig(AppConfig):
    name = 'FC17Website'
